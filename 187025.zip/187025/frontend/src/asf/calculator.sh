count = 0
while [[ $count -eq 0 ]]
do 
    tput clear
    echo "1 .Addition"
    echo "2 .Subt"
    echo "3 .Mutli"
    echo "4 .Divi"
    echo "5 .Exit"
    echo -e "Enter your choice : \c"
    read choice
    
    if [ $choice -ne 5 ]
    then    
        echo -e "Enter first number : \c"
        read a
        echo -e "Enter second number : \c"
        read b
    fi
    case $choice in 
    1)  ans=$(expr "$a" + "$b")
        echo "Addition is = $ans";;
    2)  ans=$(expr "$a" - "$b")
        echo "Sub is $ans"
        ;;
    3) ans=$(expr "$a" \* "$b")
       echo "Multi is $ans"
       ;;
    4) echo scale=2 | bc
        ans=$(expr "$a" / "$b")
        echo "Divi is $ans"
        ;;
    5) exit 1
        ;;
    *)      echo "Invalid Choice !!!"
        ;;
    esac
    sleep 3
done    