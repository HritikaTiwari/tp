package cg.plp.exception;

@SuppressWarnings("serial")
public class InvalidAuthentication extends RuntimeException {

	  public InvalidAuthentication(String msg){
	        super(msg);
	    }
	    
	    public InvalidAuthentication() {}
	
}
