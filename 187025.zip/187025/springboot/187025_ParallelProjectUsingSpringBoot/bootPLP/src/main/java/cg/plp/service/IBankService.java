package cg.plp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import cg.plp.entities.TransactionBean;
import cg.plp.entities.UserBean;

@SuppressWarnings("unused")
public interface IBankService {

	// This all service methods
	UserBean accountCreate(UserBean ub);

	UserBean logIn(int accId, String accPassword);

	int showBalance(int accId);

	int deposit(UserBean ub);

	int withdraw(UserBean ub);

	int fundTransfer(int accountId, UserBean ub);

	Set<TransactionBean> transactionList(int accountId);

}